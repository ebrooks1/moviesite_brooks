var config = {
//ADD ALL THIS STUFF INTO THIS CONFIG FILE
  host : "localhost",
  port: 8889, //3306 for LAMP/WAMP
  user: "root",
  password : "root", //blank for windows
  database : "cooperStuff"


};

module.exports = config;
